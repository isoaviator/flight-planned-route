import json
import random
from pathlib import Path
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load data
airlines = json.load(open(DATA / "airlines.json"))
airports = json.load(open(DATA / "airports.json"))
routes = json.load(open(DATA / "routes.json"))

airlines_by_icao = {a["icao"]: a for a in airlines}
airports_by_icao = {a["icao"]: a for a in airports}

# Helpers
def get_all_aircraft():
    s = set()
    for a in airlines:
        for t in a["fleet"]:
            s.add(t)
    return sorted(s)

def filter_routes(selected, rtype):
    return [
        r for r in routes
        if r["type"] == rtype and any(ac in r["aircraft"] for ac in selected)
    ]

# Endpoints
@app.get("/aircraft")
def aircraft():
    return get_all_aircraft()

@app.get("/assignment")
def assignment(aircraft: str, type: str):
    selected = aircraft.split(",")

    possible = filter_routes(selected, type)
    if not possible:
        return {"error": "No matching routes."}

    route = random.choice(possible)
    airline = airlines_by_icao[route["airline"]]

    valid_ac = list(set(selected) & set(route["aircraft"]) & set(airline["fleet"]))
    if not valid_ac:
        return {"error": "No valid aircraft for this airline."}

    ac = random.choice(valid_ac)

    dep = airports_by_icao.get(route["from"], {"name": "Unknown"})
    arr = airports_by_icao.get(route["to"], {"name": "Unknown"})

    return {
        "airline": airline["icao"],
        "callsign": f"{airline['callsign']} {random.randint(1,9999)}",
        "aircraft": ac,
        "from": route["from"],
        "to": route["to"],
        "from_name": dep["name"],
        "to_name": arr["name"]
    }
